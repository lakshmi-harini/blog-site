let firebaseConfig = {
        apiKey: "AIzaSyB-atyGmF_KXEZn6vlFFjlnUZsg6eCYTpA",
        authDomain: "blogging-site-be01a.firebaseapp.com",
        projectId: "blogging-site-be01a",
        storageBucket: "blogging-site-be01a.firebasestorage.app",
        messagingSenderId: "1078344070312",
        appId: "1:1078344070312:web:dd4e769d149b83425ffe9d"
      };
firebase.initializeApp(firebaseConfig);

let db = firebase.firestore();